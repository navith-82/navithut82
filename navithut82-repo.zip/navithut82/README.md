# Battambang Heritage Walking Tour

ដំណើរទស្សនកិច្ចតាមផ្លូវបេតិកភណ្ឌក្រុងបាត់ដំបង

A bilingual (English and Khmer) heritage website for 14 historic buildings in Battambang, Cambodia. It began as an
AUPP Liger Leadership Academy Exploration in August 2026.

## What is on the site
- Home page with a photo slideshow, featured locations and a video section
- Explore page with category filters and a page for each of the 14 locations
- Interactive heritage map. Select a marker to see the location icon, the English and Khmer names and the QR code
- Embedded YouTube video for each location

## Run it
It is a single file with no build step. Open `index.html` in a browser.

## Put it online (GitHub Pages)
1. Push these files to the `main` branch.
2. In the repository, open **Settings > Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, then select `main` and `/ (root)`.
4. After a minute the site appears at `https://<your-username>.github.io/<repository-name>/`.

YouTube players play inside the page when the site is hosted this way.

## Update the content
Everything is inside `index.html`, in the `<script>` section:
- `SITES`: names, Khmer names, short descriptions, highlights and the YouTube playlist id (`list`) for each location.
  Add `video` (an 11-character video id) to make a location play one specific video.
- `PHOTOS`: one photo per location (embedded images).
- `ASSETS`: the icon and QR code for each stop number.
- `TEACHERS` and `STUDENTS`: names on the About page.

## Credits
Teachers: Jeff Kane, Marady Heang. Students: see the About page.
Site descriptions come from the Battambang Heritage Walking Tour brochure.
